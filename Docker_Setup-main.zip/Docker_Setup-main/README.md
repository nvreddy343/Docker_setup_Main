git clone https://github.com/praveen1994dec/Docker_Setup.git
